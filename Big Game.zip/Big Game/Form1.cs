﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Big_Game
{
    class Hero
    {
        public int x, y, idnum = 0, dead = 0, climp=0,run=0;
        public string imgtype = "idel";
    }
    class elev
    {
        public int x, y, fmove = 0, oldx, robotmove = 0, ishit = 0;
    }
 
    public partial class Form1 : Form
    {
        int die = 0;
        Timer death = new Timer();
        int speed, deltax, deltay;

        Bitmap bullet = new Bitmap("bullet.png");
        Bitmap lightning = new Bitmap("lightning2.jpg");
        Bitmap ppbullet = new Bitmap("panzerBullet.jpg");
        Bitmap zombieimg = new Bitmap("zombie.png");
        elev singlebullet = new elev();
        elev firstrobot = new elev();
        elev secondrobot = new elev();
        elev panzer = new elev();
        List<elev> multipller = new List<elev>();
        List<elev> multipllel = new List<elev>();
        List<elev> zombies = new List<elev>();
        int ctattack = 0;
        Bitmap robot1 = new Bitmap("robot.png");
        Bitmap panz = new Bitmap("panzer.png");

        Bitmap lad;
        elev robot = new elev();
        elev Panzbullet = new elev();
        elev robot22 = new elev();
        elev elevator = new elev();
        elev lader = new elev();
        Bitmap off, back1 = new Bitmap("back1.jpg"), back2 = new Bitmap("back2.jpg"); 
        Hero hero = new Hero();
        elev randommove = new elev();
        elev robot2bullets = new elev();

        Timer main = new Timer();
        char faction = 'r';
        int fgump=0;
        public Form1()
        {
            main.Tick += Main_Tick;
            Load += Form1_Load;
            KeyDown += Form1_KeyDown;
            this.WindowState = FormWindowState.Maximized;
            death.Tick += Death_Tick;
            main.Start();
        }
        Bitmap nimg2;
        private void Death_Tick(object sender, EventArgs e)
        {
            if(die%10==0)
            { 
                nimg2 = new Bitmap("dead" + hero.dead + ".png");

                drawscene2(CreateGraphics());
                if (hero.dead == 6)
                {
                    death.Stop();
                    this.Close();
                }

                hero.dead++;
            }
            die++;
        }
        void drawscene2(Graphics g)
        {
            g.Clear(Color.Wheat);
            g.DrawImage(nimg2, 300, 250, 200, 200);
        }
        void moveBullets()
        {
          //  Text = Panzbullet.x + "<<" + Panzbullet.oldx;
            if (Panzbullet.x < Panzbullet.oldx -400)
            {
                Panzbullet.x = panzer.x - 150;
            }
            else
            {
                Panzbullet.x -= 15;
            }



            if (robot2bullets.x>robot22.oldx+500)
            {
                robot2bullets.x = robot22.x + 80;
            }
            else
            {
                robot2bullets.x += 15;
            }

            if(flagrobot1==1)
            {
                randommove.x -= deltax;
                randommove.y -= deltay;
            }
            if (singlebullet.fmove==1)
            {
                singlebullet.x += 15;
            }
            for(int i=0;i<multipller.Count;i++)
            {
               // Text=multipller[i].y+"<<"+panzer.y;
                multipller[i].x += 15;
            }

            for (int i = 0; i < multipllel.Count; i++)
            {
                 multipllel[i].x -= 15; 
            }
        }
        void actions(char move)////////////////////////////////////////////////////
        {
            if (move == 'u')//up
            {
                grav = 0;
                hero.y -= 10;
                hero.imgtype = "climp";
                fgump = 1;
            }
            if (move ==' ')
            {
                if (fgump == 0)
                {
                    fgump = 1;
                    hero.y -= 50;
                }
                grav = 1;
            }
            if(move=='r')
            {
                hero.x += 7;
                scroll += 10;
                elevator.x -= 30;
                lader.x -= 30;
                robot.x -= 30;
                robot22.x -= 30;
                robot22.oldx -= 30;
                panzer.x -= 30;
                panzer.oldx -= 30;
                Panzbullet.x -= 30;
                Panzbullet.oldx -= 30;
                firstrobot.x -= 30;
                secondrobot.x -= 30;
                for (int i = 0; i < multipller.Count; i++)
                {
                    multipller[i].x -= 30;
                }
                for(int i=0;i<zombies.Count;i++)
                {
                    zombies[i].x -= 30;
                }

                singlebullet.x -= 30;
                robot2bullets.x -= 30;
                grav = 1;
            }

            if (move == 'l')
            {
                hero.x -= 7;
                scroll -= 10;
                elevator.x += 30;
                grav = 1;
                lader.x += 30;
                robot.x += 30;
                robot22.oldx += 30;
                robot22.x += 30;
                panzer.x += 30;
                panzer.oldx += 30;
                Panzbullet.x += 30;
                Panzbullet.oldx += 30;
                firstrobot.x += 30;
                secondrobot.x += 30;
                for (int i=0;i<multipller.Count;i++)
                {
                    multipller[i].x += 30;
                }
                for (int i = 0; i < zombies.Count; i++)
                {
                    zombies[i].x += 30;
                }
                singlebullet.x += 30;
                robot2bullets.x += 30;
            }

        }
        int grav = 1;

        void moverobots()
        {
            
            if (robot22.x> robot22.oldx+100)//emen
            {
                robot22.robotmove = 0;
            }

            if ( robot22.x < robot22.oldx - 100)//4mal
            {
                robot22.robotmove = 1;
            }
           
          
            if (robot22.robotmove==1)
            {
                robot22.x += 5;
            }
            else
            {
                robot22.x -= 5;
            }




            if (panzer.x > panzer.oldx + 200)//emen
            {
                panzer.robotmove = 0;
            }

            if (panzer.x < panzer.oldx - 200)//4mal
            {
                panzer.robotmove = 1;
            }


            if (panzer.robotmove == 1)
            {
                panzer.x += 5;
            }
            else
            {
                panzer.x -= 5;
            }
        }
        
        void gravity()
        {

            if (hero.y != 600 && hero.y != 370 && hero.y != 150 && grav==1)
            {
                hero.y++;
            }
            else
            {
                fgump = 0;
            }
            if (grav != 1 && hero.y+75<elevator.y&&hero.x>=elevator.x)
            {
                
                hero.y++;
            }
           
          

        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            ct = 0;
            if(e.KeyCode==Keys.Down&& hero.y!=600&& hero.y!=370&& hero.y!=150)
            {
                hero.y++;
            }
            if(e.KeyCode==Keys.M)
            {
                elev pnn = new elev();
                pnn.x = hero.x + 80;
                pnn.y = hero.y + 35;
                multipller.Add(pnn);
            }

            if (e.KeyCode == Keys.L)
            {
                elev pnn = new elev();
                pnn.x = hero.x - 80;
                pnn.y = hero.y + 35;
                multipllel.Add(pnn);
            }
            if (e.KeyCode == Keys.Right)
            {
                if (faction != 'r')
                {
                    hero.x -= 75;
                }
                faction = 'r';
                hero.imgtype = "run";
                actions('r');
                
            }
            if (e.KeyCode == Keys.Left)
            {
                if(faction!='l')
                {
                    hero.x += 75;
                }
                faction = 'l';

                actions('l');
                hero.imgtype = "run";
            }
            if (e.KeyCode == Keys.Space)
            {
                
                hero.imgtype = "jump";
                actions(' ');
            }
            
          //  Text = hero.y  + "<<" + lader.y; // + "<<" + lader.y + "<<" + hero.y;
            if (e.KeyCode == Keys.Up && hero.x > lader.x/*good*/ && hero.x < lader.x + 150/*good*/
                && lader.y < hero.y - 75 && hero.y + 75 >= 370) 
            {
                sure = 0;
                actions('u');
            }

            if (e.KeyCode == Keys.Up && sure == 0)
            {
                actions('u');
                if(hero.y<=150)
                {
                    grav = 1;
                    sure = 1;
                }
            }

            if(e.KeyCode==Keys.R)
            {
                singlebullet.fmove = 1;
                singlebullet.x = hero.x + 80;
                singlebullet.y = hero.y + 35;

            }
        }
        int scroll = 200;
        void movezombies()
        {
            for(int i=0;i<zombies.Count&&flagzomb==1; i++)
            {
                zombies[i].x += 7;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            lad = new Bitmap("lader.jpg");
            lad.MakeTransparent(lad.GetPixel(0, 0)) ;
            lightning.MakeTransparent(lightning.GetPixel(0, 0));
            ppbullet.MakeTransparent(ppbullet.GetPixel(0, 0));
            panz.MakeTransparent(panz.GetPixel(0, 0));
            back1 = new Bitmap(back1, Width, Height);
            back2 = new Bitmap(back2, Width, Height);

            KeyUp += Form1_KeyUp;
            off = new Bitmap(Width * 3, Height);

            hero.x = 0;
            hero.y = 600;
            robot.x = this.Width;
            robot.oldx = this.Width;
            robot.y = 150;

            firstrobot.y = 600;
            firstrobot.x = 400;

            secondrobot.y = 600;
            secondrobot.x = 1000;


            elevator.x = 3050;
            elevator.y = 690;

            lader.x = 100;
            lader.y = 150;

            panzer.x = 2500;
            panzer.oldx = 2500;
            panzer.y = 570;
            Panzbullet.x = 2350;
            Panzbullet.y = 600;
            Panzbullet.oldx = 2350;


            robot22.x = 400;
            robot22.oldx = 400;
            robot22.y = 370;
            robot2bullets.x = 480;
            robot2bullets.y = 400;
            int x=400;
            for(int i=0;i<10;i++)
            {
                elev pnn = new elev();
                pnn.x = x;
                pnn.y = 370;
                x += 250;
                zombies.Add(pnn);
            }
            //
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            ct = 45;
        }

        int ct = 0;
        void change_pic()
        {
            if (ct > 40)
            {
                hero.imgtype = "idel";
                if (ct % 3 == 0 && hero.idnum != 9)
                {
                    hero.idnum++;
                    
                }
                else
                {
                    hero.idnum = 0;
                }
            }
            
            if (hero.imgtype == "run")
            {
                if(hero.run!=2)
                {
                    hero.run += 1;
                }
                else
                {
                    hero.run = 0;
                }
            }
            if (hero.imgtype == "climp")
            {
                if (hero.climp != 1)
                {
                    hero.climp += 1;
                }
                else
                {
                    hero.climp = 0;
                }
            }

            if (hero.imgtype == "dead")
            {
                if (hero.dead != 6)
                {
                    hero.dead += 1;
                }
                else
                {
                    main.Stop();
                }
            }

        }
        int sure = 1;
        void elevator_move()//0==up//1==down
        {
            if(elevator.fmove==0)
            {
                if(elevator.y<400)
                {
                    elevator.fmove = 1;
                }
                else
                {
                    if (elevator.y-75 == hero.y
                        &&hero.x>elevator.x-35
                        &&hero.x<elevator.x+100
                        )
                    {
                        grav = 0;
                        hero.y -= 15;
                    }
                    elevator.y -= 15;
                   
                }
            }

            if (elevator.fmove == 1)
            {
                if (elevator.y > 690)
                {
                    elevator.fmove = 0;
                }
                else 
                {
                    grav = 1;
                    elevator.y += 15;
                }
            }
        }
        int flagzomb = 0;
        private void Main_Tick(object sender, EventArgs e)
        {
            ctattack++;
            ct++;
            if(hero.y==370)
            {
                flagzomb = 1;
            }
            if(sure==0)
            {
                grav = 0;
            }
            ishit();
            kill();
            movezombies();
            moverobots();
            robot1laser();
            gravity();
            elevator_move();
            change_pic();
            moveBullets();
            
            drawdubb(CreateGraphics());
           
        }
        int xlaser1;
        int ylaser1;
        int xlaser2;
        int ylaser2;
        int flagrobot1=0;
        void robot1laser()
        {
            xlaser1= robot.x-55;
            ylaser1= robot.y +35;
            xlaser2= hero.x + 55;
            ylaser2 = hero.y;
            if(ctattack%80==0&&randommove.fmove==0)
            {
               // int distance = robot.x - hero.x;
               // speed = distance / 22;
               // deltay=distance / speed;
               // deltax = speed;
                randommove.x = robot.x - 110;
                randommove.y = robot.y + 35;
                flagrobot1 = 1;
                deltax = robot.x - hero.x-110;
                deltay = robot.y - hero.y+35;
                deltax /= 10;
                deltay /= 10;
            }
        }
        void kill()
        {
            for (int i = 0; i < multipller.Count; i++)//emen
            {
                if (multipller[i].x + 40 >= panzer.x || singlebullet.x + 40 >= panzer.x && hero.y == 600)
                {
                    panzer.fmove = 1;
                    multipller.RemoveAt(i);
                    break;
                }

                if (multipller[i].x + 40 >= robot.x && hero.y == 150)
                {
                    robot.fmove = 1;
                    multipller.RemoveAt(i);
                    break;
                }

            }

            for (int i = 0; i < multipllel.Count; i++)//4mal
            {
                if (multipllel[i].x <= robot22.x + 75 && hero.y == 370)
                {
                    robot22.fmove = 1;
                    multipllel.RemoveAt(i);
                    break;
                }
                for (int j=0;j<zombies.Count;j++)
                {
                    if (multipllel[i].x <= zombies[j].x + 75 && hero.y == 370)
                    {
                        multipllel.RemoveAt(i);
                        zombies.RemoveAt(j);
                        break;
                       
                    }
                }
              
            }
        }
        int hit = 0;
        void ishit()
        {
            Text = hit + "";
            if (Panzbullet.x <= hero.x+100
                &&hero.y==600&&hero.x<Panzbullet.x&&panzer.fmove==0
                )
            {
                hit++;
            }

            if (robot2bullets.x >= hero.x - 100
                && hero.y == 370 && hero.x >robot2bullets.x
                &&robot22.fmove==0
                )
            {
                hit++;
            }

            for(int i=0; i<zombies.Count;i++)
            {
                if (zombies[i].x >= hero.x - 80
                && hero.y == 370 && hero.x > zombies[i].x && zombies[i].ishit == 0
                )
                {
                    zombies[i].ishit = 1;
                    hit++;
                }
            }
            if(hit==7)
            {
                hero.imgtype = "dead";
                main.Stop();
                death.Start();
            }
            if (ctattack % 20 == 0)
            {
                if (hero.x > firstrobot.x && hero.x + 75 < secondrobot.x && hero.y == 600)
                {
                    hit++;
                }
            }
        }
        void draw_scene(Graphics g)
        {
          
            Bitmap nimg = new Bitmap("idel1.png");
            g.Clear(Color.White);

            g.DrawImage(back1,
                     new Rectangle(0, 0, off.Width, off.Height),//dst
                     new Rectangle(scroll, 0, Width, this.Height),//src
                     GraphicsUnit.Pixel);

            g.DrawImage(back1,
                     new Rectangle(Width-=scroll+500, 0, off.Width, off.Height),//dst
                     new Rectangle(scroll-Width, 0, Width, this.Height),//src
                     GraphicsUnit.Pixel);
            g.FillRectangle(Brushes.Red, elevator.x, elevator.y, 150, 20);
            g.DrawImage(lad, lader.x, lader.y + 75, 150, 220);
            g.DrawImage(robot1, firstrobot.x, firstrobot.y, 100, 100);
            g.DrawImage(robot1, secondrobot.x, secondrobot.y, -100, 100);
            if(ctattack%20==0|| ctattack % 21 == 0|| ctattack % 22 == 0)
            g.DrawImage(lightning, firstrobot.x+75, firstrobot.y+35, 450, 50);

            if (hero.imgtype == "idel")
            {
                nimg = new Bitmap("idel" + hero.idnum + ".png");
            }
            if (hero.imgtype == "run")
            {
                nimg = new Bitmap("run" + hero.run + ".png");
            }
            else if(hero.imgtype == "jump")
            {
                nimg = new Bitmap("jump" + 0 + ".png");
                
            }
            else if (hero.imgtype == "climp")
            {
                nimg = new Bitmap("climp" + hero.climp + ".png");
            }
            else if(hero.imgtype == "dead")
            {
                nimg = new Bitmap("dead" + hero.dead + ".png");
            }

            if (faction == 'l')
            {
                g.DrawImage(nimg, hero.x, hero.y, 75 - nimg.Width / 2 - 34, 75);
            }
            else
            {
                g.DrawImage(nimg, hero.x, hero.y, 75, 75);
            }
            if (robot.fmove == 0)
            {
                g.DrawImage(robot1, robot.x, robot.y, -75, 75);
            }
            else
            {
                main.Stop();
            }
            Pen pn = new Pen(Color.Red, 5);
          

            if(singlebullet.fmove==1)
            {
                g.DrawImage(bullet, singlebullet.x, singlebullet.y, 25, 25) ;
            }

            for(int i=0;i<multipller.Count;i++)
            {
                g.DrawImage(bullet, multipller[i].x, multipller[i].y, 25, 25);
            }
            if(flagrobot1==1&& robot.fmove == 0)
            {
                if (faction == 'r')
                    g.DrawLine(pn, xlaser1, ylaser1, xlaser2, ylaser2);
                else
                    g.DrawLine(pn, xlaser1, ylaser1, xlaser2 - 75, ylaser2);
                if (hero.x > robot.x)
                {
                    g.DrawImage(bullet, randommove.x, randommove.y, 25, 25);
                }
                else
                {
                    g.DrawImage(bullet, randommove.x, randommove.y, -25, 25);
                }
            }
            if(robot22.fmove==0)
            {
                g.DrawImage(robot1, robot22.x, robot22.y, 75, 75);
                g.DrawImage(bullet, robot2bullets.x, robot2bullets.y, 25, 25);
            }
            
           
            if (panzer.fmove != 1)
            {
                g.DrawImage(panz, panzer.x, panzer.y, -150, 150);
                g.DrawImage(ppbullet, Panzbullet.x, Panzbullet.y, -40, 40);
            }
            for(int i=0;i<zombies.Count;i++)
            {
                g.DrawImage(zombieimg, zombies[i].x, zombies[i].y, 75, 75);
            }
            for(int i=0;i<multipllel.Count; i++)
            {
                g.DrawImage(bullet, multipllel[i].x, multipllel[i].y, -25, 25);
            }

        }
        void drawdubb(Graphics g)
        {     

            off = new Bitmap(Width * 3, Height);

            Graphics g2 = Graphics.FromImage(off);
            draw_scene(g2);
            g.DrawImage(off, 0, 0);

        }

    }
}
