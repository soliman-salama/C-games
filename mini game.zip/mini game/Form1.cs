﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mini_game
{
    class obstacles
    {
        public int x, y;
        public string nblocks;
    }
    class heroo
    {
        public int x, y,ngifts,taken=0;
    }
    public partial class Form1 : Form
    {
        Bitmap worm = new Bitmap("worm.jpg");
        Bitmap cadeu = new Bitmap("gift.png");
        List<heroo> gifts = new List<heroo>();
        Bitmap dst = new Bitmap("124.jpg");
        List<heroo> hero = new List<heroo>();
        List<obstacles> baffles = new List<obstacles>();
        Bitmap off;
        Timer t2 = new Timer();
        Timer tt = new Timer();
        Timer gg = new Timer();
        public Form1()
        {
            this.WindowState = FormWindowState.Maximized;
            Load += Form1_Load;
            tt.Tick += Tt_Tick;
            t2.Tick += T2_Tick;
            gg.Tick += Gg_Tick;
            tt.Start();
            KeyDown += Form1_KeyDown;
        }
        int nogift;
        private void Gg_Tick(object sender, EventArgs e)
        {
            if(nogift==0)
            {
                gg.Stop();
                tt.Start();
            }
            else
            {
                heroo pnn = new heroo();
                pnn.x = hero[hero.Count - 1].x - 10;
                pnn.y = hero[hero.Count - 1].y;
                hero.Add(pnn);
                time = 0;
            }
            nogift--;
            drawdubb(CreateGraphics());
        }

        int picked;
        private void T2_Tick(object sender, EventArgs e)
        {
            if(int.Parse(baffles[picked].nblocks)==0)
            {
                baffles.RemoveAt(picked);
                t2.Stop();
                tt.Start();
                time = 0;
            }
            else
            {
                int z=int.Parse(baffles[picked].nblocks);
                z--;
                baffles[picked].nblocks = z + "";
                if (hero.Count != 1)
                {
                    hero.RemoveAt(hero.Count - 1);
                }
                else
                {
                    t2.Stop();
                    MessageBox.Show("loser");
                }
            }
            drawdubb(CreateGraphics());
        }
        char mov = 'l';
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode==Keys.Up && mov != 'u')
            {
                mov = 'u';
                move();
            }


            if (e.KeyCode == Keys.Down && mov != 'd') 
            {
                
                mov = 'd';
                move();
            }

        }
        void hit()
        {
            for(int i=0;i<baffles.Count;i++)
            {
                if (hero[0].x < baffles[i].x
                    && hero[0].x > baffles[i].x - 10
                    && hero[0].y > baffles[i].y
                    && hero[0].y + 10 < baffles[i].y + 100)
                {

                    tt.Stop();
                    t2.Start();
                    picked = i;
                    time = 1;
                }
            }
        }
        int ct = 0;
        int position = 0;
        void moveshapes()
        {
            for (int i=0;i<gifts.Count;i++)
            {
                gifts[i].x -= 7;
            }

            for (int i = 0; i < baffles.Count; i++)
            {
                baffles[i].x -= 7;
            }
        }
        private void Tt_Tick(object sender, EventArgs e)
        {
            moveshapes();
            Text = position + "";
            present();
            if (position != 650)
            {
                position++;
            }
            else
            {
                tt.Stop();
                MessageBox.Show("winner");
            }
            hit();
            hero[0].x += 2;
            move();
            //drawscene(CreateGraphics());
            drawdubb(CreateGraphics());
            
        }
       
        void move()
        {
            for(int i= hero.Count-2; i>=0;i--)
            {
                hero[i + 1].x = hero[i].x-10;
                hero[i + 1].y = hero[i].y;
            }
            if(mov=='u')
            {
                hero[0].y -= 10;
            }
            else
            {
                hero[0].y += 10;
            }
            
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            dst = new Bitmap(dst, Width * 3, Height);
            Random rr = new Random();
            int cellsnum = rr.Next(3, 24);
            int x = 120;
            for(int i=0;i<cellsnum;i++)
            {
                heroo pnn = new heroo();
                pnn.x = x;
                pnn.y = Height / 2;
                hero.Add(pnn);

                x -= 10;
            }
            x = 50;
            int y=0;
            for (int i = 0; x < Width * 4; i++)
            {
                for (int z = 0; z < 6; z++)
                {
                    y = rr.Next(0,Height-170);
                    obstacles pnn = new obstacles();
                    pnn.x = x;
                    pnn.y = y;
                    int check = 1;
                    for(int w=0;w<baffles.Count;w++)
                    {
                       

                        if (pnn.x == baffles[w].x
                            &&pnn.y>baffles[w].y//tmm
                            &&pnn.y<baffles[w].y+100
                            || pnn.x == baffles[w].x
                            && pnn.y < baffles[w].y
                            && pnn.y + 100 > baffles[w].y
                            )
                        {
                            check = 0;
                        }

                    }
                    if (check == 1)
                    {
                        int num = rr.Next(10);
                        pnn.nblocks = num.ToString();
                        baffles.Add(pnn);
                    }
                    else
                    {
                        i--; 
                    }
                }

                x += 100;
            }


            int g = rr.Next(10, 30);
            for(int i=0;i<g;i++)
            {
                x = rr.Next(Width * 3);
                y = rr.Next(Height - 150);
                heroo pnn = new heroo();
                pnn.x = x;
                pnn.y = y;
                pnn.ngifts = rr.Next(10);
                gifts.Add(pnn);
            }

        }//
        int time;
        void present()
        {

            for (int i = 0; i < gifts.Count; i++)
            {
                if (hero[0].x <    gifts[i].x
                    && hero[0].x > gifts[i].x - 10
                    && hero[0].y > gifts[i].y
                    && hero[0].y + 10 < gifts[i].y + 100)
                {
                    if (gifts[i].taken == 0)
                    {
                        nogift = gifts[i].ngifts;
                        tt.Stop();
                        gg.Start();
                        time = 1;
                        gifts[i].taken = 1;
                    }
                }

                if (hero[0].x > gifts[i].x
                    && hero[0].x + 10 < gifts[i].x + 70 
                    && hero[0].y > gifts[i].y
                    && hero[0].y + 10 < gifts[i].y + 100)
                {
                    if (gifts[i].taken == 0)
                    {
                        nogift = gifts[i].ngifts;
                        tt.Stop();
                        gg.Start();
                        time = 1;
                        gifts[i].taken = 1;
                    }
                }

            }
        }
        void drawscene(Graphics g)
        {
            
            g.Clear(Color.White);
             g.DrawImage(dst,
                      new Rectangle(0,0, off.Width, off.Height),//dst
                      new Rectangle(hero[0].x,0, Width, Height),//src
                      GraphicsUnit.Pixel);

            
            
            for (int i=0;i<baffles.Count;i++)
            {
                if (hero[0].x < baffles[i].x+50)
                {
                    g.FillRectangle(Brushes.Black, baffles[i].x, baffles[i].y, 5, 100);
                    g.DrawString(baffles[i].nblocks, this.Font, Brushes.Red, baffles[i].x, baffles[i].y);
                    
                }
            }

            for(int i=0;i<gifts.Count;i++)
            {
                g.DrawImage(cadeu, gifts[i].x, gifts[i].y, 70, 70) ;
                g.DrawString(gifts[i].ngifts.ToString(), this.Font, Brushes.Red, gifts[i].x, gifts[i].y);
               
            }

            for(int i=0;i<hero.Count;i++)
            {
                g.FillEllipse(Brushes.Red, hero[i].x, hero[i].y, 10, 10);
            }
           // g.DrawImage(worm, hero[0].x, hero[0].y, 30, 30);
        }
        void drawdubb(Graphics g)
        {
            // g.Clear(Color.Wheat);

            off = new Bitmap(Width*3, Height);
            
            Graphics g2 = Graphics.FromImage(off);
            drawscene(g2);
            g.DrawImage(off,0,0);
           
        }
    }
}
